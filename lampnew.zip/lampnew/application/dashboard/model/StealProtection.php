<?php
/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 2018/5/29
 * Time: 17:33
 */

namespace app\dashboard\model;


class StealProtection extends \think\Model
{

}